
import React, { useState, useEffect } from 'react';
import { ViewState, Subject, Chapter, Question, TestResult } from './types';
import { SUBJECTS } from './constants';
import { generateQuestions } from './geminiService';

const Logo: React.FC = () => (
  <div className="flex items-center gap-3 group transition-transform hover:scale-105 duration-500 cursor-pointer">
    <div className="relative w-12 h-12 flex items-center justify-center">
      {/* 3D-effect background for the 'AJ' mark with purple theme */}
      <div className="absolute inset-0 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-2xl rotate-6 group-hover:rotate-12 transition-all duration-500 shadow-xl shadow-purple-200/50"></div>
      <div className="absolute inset-0 bg-white/20 backdrop-blur-sm rounded-2xl -rotate-3 group-hover:rotate-3 transition-all duration-500 border border-white/30"></div>
      <span className="relative z-10 text-white font-normal text-xl mark-font tracking-tight drop-shadow-md">
        AJ
      </span>
    </div>
    <div className="flex flex-col">
      <span className="text-4xl font-bold logo-font tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-purple-600 to-indigo-800 leading-none py-1">
        ArJa
      </span>
      <div className="flex items-center gap-1 -mt-1">
        <div className="h-[1px] w-4 bg-purple-300 rounded-full"></div>
        <span className="text-[9px] font-black text-purple-500 tracking-[0.3em] uppercase leading-none">
          Academy
        </span>
      </div>
    </div>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>(ViewState.HOME);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(new Array(30).fill(null));
  const [achievements, setAchievements] = useState<TestResult[]>([]);
  const [userProfile] = useState({ name: 'Student', email: 'student@arja.com' });

  // Initial load: check local storage for achievements
  useEffect(() => {
    const saved = localStorage.getItem('arja_achievements');
    if (saved) {
      setAchievements(JSON.parse(saved));
    }
  }, []);

  const startTest = async (chapter: Chapter) => {
    if (!selectedSubject) return;
    setLoading(true);
    setSelectedChapter(chapter);
    try {
      const qs = await generateQuestions(selectedSubject.name, chapter.name, selectedSubject.class);
      setQuestions(qs);
      setUserAnswers(new Array(qs.length).fill(null));
      setCurrentQuestionIndex(0);
      setView(ViewState.TEST);
    } catch (err) {
      alert("Failed to load questions. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const calculateScore = () => {
    let totalScore = 0;
    let correct = 0;
    let wrong = 0;
    let unattempted = 0;

    userAnswers.forEach((answer, idx) => {
      if (answer === null) {
        unattempted++;
      } else if (answer === questions[idx].correctAnswer) {
        correct++;
        totalScore += 4;
      } else {
        wrong++;
        totalScore -= 1;
      }
    });

    const result: TestResult = {
      date: new Date().toLocaleDateString(),
      subject: selectedSubject?.name || '',
      chapter: selectedChapter?.name || '',
      score: totalScore,
      totalQuestions: questions.length,
      correct,
      wrong,
      unattempted
    };

    const updatedAchievements = [result, ...achievements];
    setAchievements(updatedAchievements);
    localStorage.setItem('arja_achievements', JSON.stringify(updatedAchievements));
    setView(ViewState.SCORECARD);
  };

  const handleSelectAnswer = (optionIdx: number) => {
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = optionIdx;
    setUserAnswers(newAnswers);
  };

  const handleNav = (target: ViewState) => {
    setView(target);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/40 z-40 transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 w-72 bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-8 border-b flex justify-between items-center bg-purple-50/30">
          <h2 className="text-3xl font-bold text-purple-600 logo-font">Menu</h2>
          <button onClick={() => setSidebarOpen(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-white shadow-sm border text-gray-400 hover:text-purple-600 hover:border-purple-200 transition-all">
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>
        <nav className="p-6 space-y-3">
          <button 
            onClick={() => handleNav(ViewState.HOME)}
            className="w-full text-left p-4 rounded-2xl hover:bg-purple-50 text-gray-700 font-bold flex items-center gap-4 transition-all hover:translate-x-1"
          >
            <i className="fa-solid fa-house-chimney w-6 text-purple-500 text-lg"></i> Home
          </button>
          <button 
            onClick={() => handleNav(ViewState.PROFILE)}
            className="w-full text-left p-4 rounded-2xl hover:bg-purple-50 text-gray-700 font-bold flex items-center gap-4 transition-all hover:translate-x-1"
          >
            <i className="fa-solid fa-circle-user w-6 text-purple-500 text-lg"></i> My Profile
          </button>
          <button 
            onClick={() => handleNav(ViewState.ACHIEVEMENTS)}
            className="w-full text-left p-4 rounded-2xl hover:bg-purple-50 text-gray-700 font-bold flex items-center gap-4 transition-all hover:translate-x-1"
          >
            <i className="fa-solid fa-chart-line w-6 text-purple-500 text-lg"></i> My Achievements
          </button>
        </nav>
      </div>

      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b h-24 flex items-center justify-between px-8 sticky top-0 z-30 shadow-sm border-purple-50">
        <button onClick={() => setSidebarOpen(true)} className="w-12 h-12 flex items-center justify-center rounded-2xl bg-gray-50 text-gray-600 hover:text-purple-600 hover:bg-purple-50 transition-all shadow-sm">
          <i className="fa-solid fa-bars-staggered text-xl"></i>
        </button>
        <div 
          className="absolute left-1/2 -translate-x-1/2"
          onClick={() => setView(ViewState.HOME)}
        >
          <Logo />
        </div>
        <div className="w-12 flex justify-end">
          {view === ViewState.TEST && currentQuestionIndex === questions.length - 1 && (
            <button 
              onClick={calculateScore}
              className="bg-green-600 text-white px-5 py-2.5 rounded-2xl text-sm font-black shadow-lg shadow-green-100 hover:bg-green-700 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
            >
              <i className="fa-solid fa-check-double"></i> SAVE
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-6 max-w-4xl mx-auto w-full">
        {loading && (
          <div className="fixed inset-0 bg-white/80 backdrop-blur-md z-[100] flex flex-col items-center justify-center gap-6">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-purple-100 border-t-purple-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center text-purple-600 font-normal mark-font text-xs">AJ</div>
            </div>
            <p className="text-purple-600 font-bold logo-font text-2xl animate-pulse tracking-tight">Curating NCERT Excellence...</p>
          </div>
        )}

        {view === ViewState.HOME && (
          <div className="space-y-6 py-6 animate-in fade-in duration-500">
            <div className="flex flex-col items-center text-center mb-10">
              <span className="text-xs font-black text-purple-500 uppercase tracking-[0.4em] mb-2">Academic Portal</span>
              <h2 className="text-5xl font-bold text-gray-800 logo-font">Explore Subjects</h2>
              <div className="w-16 h-1 bg-gradient-to-r from-purple-400 to-indigo-600 rounded-full mt-4"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SUBJECTS.map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => {
                    setSelectedSubject(subject);
                    setView(ViewState.CHAPTERS);
                  }}
                  className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm hover:shadow-2xl hover:shadow-purple-100/50 hover:border-purple-200 hover:-translate-y-1 transition-all text-left flex items-center justify-between group relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-purple-50/30 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform duration-700"></div>
                  <div className="relative z-10">
                    <p className="text-xs font-black text-purple-500 uppercase tracking-[0.2em] mb-2">Class {subject.class}</p>
                    <h3 className="text-3xl font-bold text-gray-800 logo-font group-hover:text-purple-600 transition-colors">{subject.name}</h3>
                  </div>
                  <div className="relative z-10 w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-all shadow-sm">
                    <i className="fa-solid fa-arrow-right-long text-lg"></i>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {view === ViewState.CHAPTERS && selectedSubject && (
          <div className="space-y-6 py-6 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex items-center gap-6 mb-8 bg-white p-6 rounded-3xl shadow-sm border border-purple-50">
              <button onClick={() => setView(ViewState.HOME)} className="w-12 h-12 flex items-center justify-center rounded-2xl bg-purple-50 text-purple-600 hover:bg-purple-600 hover:text-white transition-all shadow-inner">
                <i className="fa-solid fa-arrow-left"></i>
              </button>
              <div>
                <h2 className="text-4xl font-bold text-gray-800 logo-font leading-tight">
                  {selectedSubject.name}
                </h2>
                <p className="text-[10px] font-black text-purple-400 uppercase tracking-[0.3em]">Class {selectedSubject.class} Curriculum</p>
              </div>
            </div>
            <div className="space-y-4">
              {selectedSubject.chapters.map((chapter, idx) => (
                <button
                  key={chapter.id}
                  onClick={() => startTest(chapter)}
                  className="w-full bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg hover:border-purple-200 transition-all text-left flex items-center justify-between group"
                >
                  <div className="flex items-center gap-5">
                     <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center text-xs font-black text-gray-400 group-hover:bg-purple-600 group-hover:text-white transition-all">
                       {idx + 1}
                     </div>
                     <span className="text-gray-800 font-bold text-2xl logo-font group-hover:text-purple-600 transition-colors">{chapter.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-[9px] font-black bg-purple-50 text-purple-600 px-3 py-1.5 rounded-full uppercase tracking-widest border border-purple-100">30 Questions</span>
                    <i className="fa-solid fa-circle-play text-3xl text-purple-200 group-hover:text-purple-600 transition-all group-hover:scale-110"></i>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {view === ViewState.TEST && questions.length > 0 && (
          <div className="flex-1 flex flex-col py-6 animate-in zoom-in-95 duration-500">
            <div className="mb-10">
              <div className="flex justify-between items-end mb-4">
                <div>
                  <h4 className="text-xs font-black text-purple-500 uppercase tracking-widest mb-1">{selectedChapter?.name}</h4>
                  <span className="text-3xl font-bold text-gray-800 logo-font tracking-tight">Question {currentQuestionIndex + 1} <span className="text-gray-300 font-normal">/ {questions.length}</span></span>
                </div>
                <div className="px-4 py-2 bg-white rounded-2xl border border-purple-100 shadow-sm">
                   <span className="text-[10px] text-purple-600 font-black uppercase tracking-widest">NCERT CORE</span>
                </div>
              </div>
              <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden p-0.5 border border-white shadow-inner">
                <div 
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 h-full rounded-full transition-all duration-700 ease-out" 
                  style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
                ></div>
              </div>
            </div>

            <div className="bg-white p-10 rounded-[3rem] shadow-2xl border border-purple-50/50 flex-1 flex flex-col relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                 <i className="fa-solid fa-quote-right text-8xl text-purple-600"></i>
              </div>
              
              <p className="text-2xl text-gray-800 font-bold leading-relaxed mb-12 relative z-10">
                {questions[currentQuestionIndex].question}
              </p>
              
              <div className="grid grid-cols-1 gap-4 flex-1">
                {questions[currentQuestionIndex].options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectAnswer(idx)}
                    className={`w-full p-6 rounded-3xl border-2 text-left transition-all duration-300 flex items-center gap-6 group/opt ${
                      userAnswers[currentQuestionIndex] === idx 
                        ? 'border-purple-600 bg-purple-50/50 text-purple-800 shadow-xl shadow-purple-100/50 ring-4 ring-purple-50' 
                        : 'border-gray-50 hover:border-purple-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg shrink-0 transition-all ${
                      userAnswers[currentQuestionIndex] === idx 
                      ? 'bg-purple-600 text-white shadow-lg rotate-12' 
                      : 'bg-gray-100 text-gray-400 group-hover/opt:bg-purple-100 group-hover/opt:text-purple-500'
                    }`}>
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <span className="text-lg font-bold">{option}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-between items-center pt-10 sticky bottom-0">
              <button
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
                className="flex items-center gap-3 px-10 py-5 rounded-[2rem] bg-white border-2 border-gray-100 text-gray-600 font-black shadow-lg hover:bg-gray-50 hover:border-purple-200 hover:text-purple-600 disabled:opacity-30 transition-all active:scale-95 uppercase text-xs tracking-widest"
              >
                <i className="fa-solid fa-chevron-left"></i> Prev
              </button>
              <button
                disabled={currentQuestionIndex === questions.length - 1}
                onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
                className="flex items-center gap-3 px-10 py-5 rounded-[2rem] bg-gradient-to-br from-purple-600 to-indigo-700 text-white font-black shadow-2xl shadow-purple-200 hover:scale-105 hover:brightness-110 disabled:opacity-30 transition-all active:scale-95 uppercase text-xs tracking-widest"
              >
                Next <i className="fa-solid fa-chevron-right"></i>
              </button>
            </div>
          </div>
        )}

        {view === ViewState.SCORECARD && (
          <div className="py-10 animate-in zoom-in-95 duration-700">
            <div className="bg-white rounded-[4rem] shadow-2xl border border-purple-50 overflow-hidden">
              <div className="bg-gradient-to-br from-purple-700 via-purple-600 to-violet-900 p-16 text-center text-white relative">
                <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                  <div className="absolute top-10 left-10 w-20 h-20 border-4 border-white rounded-full"></div>
                  <div className="absolute bottom-10 right-10 w-32 h-32 border-4 border-white rounded-[3rem] rotate-12"></div>
                </div>
                <div className="w-28 h-28 bg-white/20 backdrop-blur-xl rounded-[2rem] flex items-center justify-center mx-auto mb-8 rotate-12 shadow-2xl border border-white/20">
                  <i className="fa-solid fa-graduation-cap text-6xl drop-shadow-lg"></i>
                </div>
                <h2 className="text-5xl font-bold mb-3 logo-font tracking-tight">Assessment Report</h2>
                <p className="opacity-80 font-bold text-xl tracking-tight">{selectedChapter?.name}</p>
              </div>
              
              <div className="p-14">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                  <div className="bg-gradient-to-br from-green-50 to-emerald-100/30 p-10 rounded-[3rem] border border-green-100 text-center shadow-inner">
                    <p className="text-[10px] text-green-600 font-black uppercase tracking-[0.4em] mb-3">Final Merit Score</p>
                    <p className="text-6xl font-bold text-green-700 logo-font">
                      {achievements[0]?.score}
                      <span className="text-sm font-black text-green-600/50 ml-2 tracking-widest uppercase">pts</span>
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-purple-50 to-indigo-100/30 p-10 rounded-[3rem] border border-purple-100 text-center shadow-inner">
                    <p className="text-[10px] text-purple-600 font-black uppercase tracking-[0.4em] mb-3">Correct Responses</p>
                    <p className="text-6xl font-bold text-purple-700 logo-font">
                      {achievements[0]?.correct}
                      <span className="text-sm font-black text-purple-600/50 ml-2 tracking-widest uppercase">/ 30</span>
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-14">
                  <div className="flex justify-between items-center p-7 bg-red-50/50 rounded-3xl border border-red-100">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-red-600">
                        <i className="fa-solid fa-circle-xmark"></i>
                      </div>
                      <span className="text-red-700 font-bold uppercase text-xs tracking-widest">Inaccurate</span>
                    </div>
                    <span className="text-red-600 font-bold text-3xl logo-font">-{achievements[0]?.wrong}</span>
                  </div>
                  <div className="flex justify-between items-center p-7 bg-gray-50 rounded-3xl border border-gray-100">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-gray-200 flex items-center justify-center text-gray-500">
                        <i className="fa-solid fa-circle-minus"></i>
                      </div>
                      <span className="text-gray-600 font-bold uppercase text-xs tracking-widest">Omitted</span>
                    </div>
                    <span className="text-gray-500 font-bold text-3xl logo-font">{achievements[0]?.unattempted}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <button 
                    onClick={() => setView(ViewState.EXPLANATIONS)}
                    className="w-full py-6 bg-gradient-to-r from-purple-600 to-indigo-700 text-white rounded-3xl font-bold shadow-2xl shadow-purple-200 hover:scale-[1.02] hover:brightness-110 transition-all flex items-center justify-center gap-4 text-2xl logo-font"
                  >
                    <i className="fa-solid fa-lightbulb"></i> View Analysis
                  </button>
                  <button 
                    onClick={() => setView(ViewState.HOME)}
                    className="w-full py-6 bg-gray-100 text-gray-700 rounded-3xl font-bold hover:bg-gray-200 transition-all text-2xl logo-font"
                  >
                    Return Home
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === ViewState.EXPLANATIONS && (
          <div className="py-8 space-y-8 animate-in fade-in duration-500">
            <div className="flex items-center gap-6 sticky top-24 bg-[#f8fafc]/90 backdrop-blur-xl p-6 rounded-3xl z-20 border border-purple-50 shadow-sm">
              <button onClick={() => setView(ViewState.SCORECARD)} className="w-12 h-12 flex items-center justify-center rounded-2xl bg-white border border-purple-100 text-purple-600 hover:bg-purple-600 hover:text-white transition-all shadow-sm">
                <i className="fa-solid fa-arrow-left"></i>
              </button>
              <div>
                <h2 className="text-4xl font-bold text-gray-800 logo-font tracking-tight">Detailed Analysis</h2>
                <p className="text-[10px] font-black text-purple-400 uppercase tracking-[0.4em]">NCERT Conceptual Breakdown</p>
              </div>
            </div>
            
            {questions.map((q, idx) => {
              const isCorrect = userAnswers[idx] === q.correctAnswer;
              const isUnattempted = userAnswers[idx] === null;
              
              return (
                <div key={idx} className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100 flex flex-col gap-8 animate-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${idx * 80}ms` }}>
                  <div className="flex justify-between items-start gap-6">
                    <h3 className="text-2xl font-bold text-gray-800 leading-relaxed logo-font">
                      <span className="text-purple-600 mr-3 opacity-30 font-black">#{idx + 1}</span> {q.question}
                    </h3>
                    <div className={`shrink-0 px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-sm border ${
                      isUnattempted 
                      ? 'bg-gray-50 text-gray-400 border-gray-200' 
                      : isCorrect 
                        ? 'bg-green-50 text-green-600 border-green-200' 
                        : 'bg-red-50 text-red-600 border-red-200'
                    }`}>
                      {isUnattempted ? 'Omitted' : isCorrect ? 'Correct' : 'Incorrect'}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {q.options.map((opt, oIdx) => (
                      <div 
                        key={oIdx}
                        className={`p-5 rounded-2xl text-sm flex items-center gap-4 border-2 transition-all ${
                          oIdx === q.correctAnswer 
                            ? 'bg-green-50 border-green-200 text-green-800 font-bold shadow-sm' 
                            : userAnswers[idx] === oIdx 
                              ? 'bg-red-50 border-red-200 text-red-800 font-bold' 
                              : 'bg-gray-50 border-gray-50 text-gray-600 opacity-60'
                        }`}
                      >
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-xs font-black shadow-sm ${
                          oIdx === q.correctAnswer ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-500'
                        }`}>
                          {String.fromCharCode(65 + oIdx)}
                        </div>
                        <span className="font-bold">{opt}</span>
                      </div>
                    ))}
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-indigo-50/50 p-8 rounded-[2rem] border-l-8 border-purple-500 shadow-inner">
                    <div className="flex items-center gap-3 mb-4">
                       <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs">
                          <i className="fa-solid fa-lightbulb"></i>
                       </div>
                       <p className="text-[10px] font-black text-purple-600 uppercase tracking-[0.4em]">Theoretical Basis</p>
                    </div>
                    <p className="text-xl text-purple-900 leading-relaxed font-bold logo-font">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
            
            <button 
              onClick={() => setView(ViewState.HOME)}
              className="w-full py-6 bg-gradient-to-r from-purple-600 to-indigo-800 text-white rounded-3xl font-bold shadow-2xl shadow-purple-200 hover:scale-[1.02] transition-all mt-10 text-2xl logo-font"
            >
              Finish Review
            </button>
          </div>
        )}

        {view === ViewState.PROFILE && (
          <div className="py-10 animate-in slide-in-from-bottom-8 duration-700">
             <div className="bg-white rounded-[4rem] p-16 shadow-2xl border border-purple-50/50 flex flex-col items-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-purple-50 to-indigo-50"></div>
                <div className="relative z-10 w-36 h-36 bg-gradient-to-br from-purple-500 via-purple-600 to-indigo-800 rounded-[2.5rem] flex items-center justify-center text-white text-6xl font-black mb-8 shadow-2xl shadow-purple-300/50 rotate-3 border-4 border-white">
                  {userProfile.name.charAt(0)}
                </div>
                <h2 className="relative z-10 text-5xl font-bold text-gray-800 logo-font tracking-tight">{userProfile.name}</h2>
                <p className="relative z-10 text-purple-500 font-black uppercase tracking-[0.3em] text-xs mb-10">{userProfile.email}</p>
                
                <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-8 border-t border-gray-100 pt-12">
                  <div className="p-10 rounded-[2.5rem] bg-gray-50 border border-gray-100 group hover:bg-white hover:shadow-xl transition-all duration-500">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em] mb-4">Assessments Attempted</p>
                    <p className="text-6xl font-bold text-gray-800 logo-font group-hover:text-purple-600 transition-colors">{achievements.length}</p>
                  </div>
                  <div className="p-10 rounded-[2.5rem] bg-purple-50 border border-purple-100 group hover:bg-purple-600 transition-all duration-500">
                    <p className="text-[10px] font-black text-purple-400 uppercase tracking-[0.4em] mb-4 group-hover:text-purple-100 transition-colors">Cumulative Avg</p>
                    <p className="text-6xl font-bold text-purple-700 logo-font group-hover:text-white transition-colors">
                      {achievements.length > 0 
                        ? Math.round(achievements.reduce((acc, curr) => acc + curr.score, 0) / achievements.length) 
                        : 0}
                    </p>
                  </div>
                </div>
             </div>
          </div>
        )}

        {view === ViewState.ACHIEVEMENTS && (
          <div className="py-10 animate-in slide-in-from-right-8 duration-700">
            <div className="flex flex-col mb-12">
              <span className="text-xs font-black text-purple-500 uppercase tracking-[0.4em] mb-3">Academic Milestones</span>
              <h2 className="text-5xl font-bold text-gray-800 logo-font tracking-tight">Performance Analytics</h2>
            </div>
            
            {achievements.length === 0 ? (
              <div className="text-center py-32 bg-white rounded-[4rem] border-4 border-dashed border-purple-50 shadow-inner">
                <div className="w-24 h-24 bg-purple-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 rotate-12">
                  <i className="fa-solid fa-hourglass-half text-5xl text-purple-200"></i>
                </div>
                <p className="text-gray-400 font-bold text-3xl logo-font mb-6 tracking-tight">Dataset currently empty</p>
                <button 
                  onClick={() => setView(ViewState.HOME)} 
                  className="bg-gradient-to-r from-purple-600 to-indigo-700 text-white px-12 py-5 rounded-[2rem] font-black shadow-2xl shadow-purple-200 hover:scale-110 active:scale-95 transition-all logo-font uppercase tracking-widest text-sm"
                >
                  Initiate First Test
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {achievements.map((res, idx) => (
                  <div key={idx} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 flex items-center justify-between group hover:border-purple-400 hover:shadow-2xl hover:shadow-purple-100/30 transition-all cursor-default relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-2 h-full bg-purple-600 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="flex items-center gap-8">
                      <div className="w-16 h-16 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 font-black text-lg logo-font shadow-inner">
                        #{achievements.length - idx}
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-purple-500 uppercase tracking-[0.3em] mb-2">{res.date}</p>
                        <h3 className="text-3xl font-bold text-gray-800 logo-font group-hover:text-purple-600 transition-colors leading-tight">{res.chapter}</h3>
                        <p className="text-xs text-gray-400 font-black uppercase tracking-[0.2em] mt-1">{res.subject}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-6xl font-bold text-gray-800 logo-font">{res.score}</p>
                      <div className="flex items-center gap-2 justify-end mt-1">
                         <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                         <p className="text-[10px] font-black text-green-600 uppercase tracking-widest">{res.correct} Accurate</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Persistent Footer */}
      {view === ViewState.HOME && (
        <footer className="bg-white/50 backdrop-blur-md border-t border-purple-50 p-10 text-center">
          <p className="text-[11px] font-black text-gray-400 uppercase tracking-[0.5em] logo-font">ArJa Intelligence Systems &copy; 2024</p>
        </footer>
      )}
    </div>
  );
};

export default App;
