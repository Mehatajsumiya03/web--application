
export enum ViewState {
  HOME = 'HOME',
  CHAPTERS = 'CHAPTERS',
  TEST = 'TEST',
  SCORECARD = 'SCORECARD',
  EXPLANATIONS = 'EXPLANATIONS',
  PROFILE = 'PROFILE',
  ACHIEVEMENTS = 'ACHIEVEMENTS'
}

export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Chapter {
  id: string;
  name: string;
}

export interface Subject {
  id: string;
  name: string;
  class: number;
  chapters: Chapter[];
}

export interface TestResult {
  date: string;
  subject: string;
  chapter: string;
  score: number;
  totalQuestions: number;
  correct: number;
  wrong: number;
  unattempted: number;
}
